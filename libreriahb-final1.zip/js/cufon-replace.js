Cufon.replace('#header .row-1 ul li a.active', { fontFamily: 'Myriad Pro Semibold', textShadow:'#ededed 1px 1px' });
Cufon.replace('#header .row-1 ul li a', { fontFamily: 'Myriad Pro Semibold', hover:{textShadow:'#ededed 1px 1px'} });
Cufon.replace('#header .row-1 ul li a.active', { fontFamily: 'Myriad Pro Semibold', textShadow:'#ededed 1px 1px' });
Cufon.replace('#header .row-2 a', { fontFamily: 'Myriad Pro Semibold', hover:true });
Cufon.replace('h3, h4', { fontFamily: 'Myriad Pro Regular' });