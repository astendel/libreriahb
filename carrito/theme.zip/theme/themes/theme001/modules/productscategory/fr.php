<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productscategory}prestashop>productscategory_db33983df8ef521000b0ab60dcb5a83f'] = 'Dans la même catégorie';
$_MODULE['<{productscategory}prestashop>productscategory_c167dc9a6cdefdab35fb3b5e325cc815'] = 'Affiche la liste des produits dans la même catégorie que celui affiché';
$_MODULE['<{productscategory}prestashop>productscategory_3029e678e2d59c6f5e1d450e9b6c03a7'] = 'Dans la même catégorie';
$_MODULE['<{productscategory}prestashop>productscategory_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_MODULE['<{productscategory}prestashop>productscategory_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Suivant';
