<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcurrencies}prestashop>blockcurrencies_f7a31ae8f776597d4282bd3b1013f08b'] = 'Bloc devises';
$_MODULE['<{blockcurrencies}prestashop>blockcurrencies_772f0a6939823dab4f40c628b800e758'] = 'Ajoute un bloc permettant au client de choisir sa devise';
$_MODULE['<{blockcurrencies}prestashop>blockcurrencies_386c339d37e737a436499d423a77df0c'] = 'Devises';
