<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockstore}prestashop>blockstore_50d335623ef166aeea8da2a3c2c63a3e'] = 'Bloque locales';
$_MODULE['<{blockstore}prestashop>blockstore_7118171dfc2981fd3d7f3aab97fb572d'] = 'Mostrar un bloque con un link hacia la lista de locales';
$_MODULE['<{blockstore}prestashop>blockstore_f32a6c9e15dd20152ee8b14c7f94b040'] = 'imagen no válida';
$_MODULE['<{blockstore}prestashop>blockstore_10857d5f8e303905ada328b4a31d316b'] = 'se ha producido un error durante el envío';
$_MODULE['<{blockstore}prestashop>blockstore_7ccf58c950043c9fbfed668df13ce608'] = 'Parámetros actualizados';
$_MODULE['<{blockstore}prestashop>blockstore_dbd41b964013caae2d73220618b5ae90'] = 'Configuració del bloque locales';
$_MODULE['<{blockstore}prestashop>blockstore_2dd1d28275cdb8b78ebd17f6e25aac0d'] = 'Imagen del bloque';
$_MODULE['<{blockstore}prestashop>blockstore_8c38cf08a0d0a01bd44c682479432350'] = 'Cambiar de imagen:';
$_MODULE['<{blockstore}prestashop>blockstore_f6f1e75fd6d515138c3c802459aa384d'] = 'la imagen se mostrará en formato 174x115';
$_MODULE['<{blockstore}prestashop>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockstore}prestashop>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'Nuestro local';
$_MODULE['<{blockstore}prestashop>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Descubra nuestro local';
