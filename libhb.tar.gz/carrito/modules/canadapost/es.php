<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{canadapost}prestashop>canadapost_e7bb7d2ee4d79c9b48cfc443781f00b5'] = 'No se puede conectar a los webservices de Canada Post';
$_MODULE['<{canadapost}prestashop>canadapost_73e383f703902e137c2e6d8e2e85cc22'] = 'Bienvenido al módulo configurador de Canada Post';
