<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statslive}prestashop>statslive_fa55230e9791f2b71322869318a5f00f'] = 'Visitantes en línea';
$_MODULE['<{statslive}prestashop>statslive_b8a5ea9b6e7f2d0b56fbb18e5b6b9246'] = 'Mostrar la lista de clientes y visitantes conectados';
$_MODULE['<{statslive}prestashop>statslive_fd42d96861238b1cd5859585c4351eca'] = 'Debe activar la opción \"páginas vistas por cada cliente\" en el módulo \"Recuperación de datos estadíisticos\" para visualizar las páginas consultadas por sus clientes.';
$_MODULE['<{statslive}prestashop>statslive_5c948349bdf1a7a77ba54497d019e4ca'] = 'Clientes en línea';
$_MODULE['<{statslive}prestashop>statslive_66c4c5112f455a19afde47829df363fa'] = 'Total:';
$_MODULE['<{statslive}prestashop>statslive_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statslive}prestashop>statslive_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{statslive}prestashop>statslive_f88589c3e803217e3f6fe9d8e740e6e8'] = 'Página en curso';
$_MODULE['<{statslive}prestashop>statslive_4351cfebe4b61d8aa5efa1d020710005'] = 'Vista';
$_MODULE['<{statslive}prestashop>statslive_2fb60e2c82df1e84e827b2f50661403e'] = 'No hay clientes en línea';
$_MODULE['<{statslive}prestashop>statslive_adb831a7fdd83dd1e2a309ce7591dff8'] = 'Visitante';
$_MODULE['<{statslive}prestashop>statslive_a12a3079e14ced46e69ba52b8a90b21a'] = 'IP';
$_MODULE['<{statslive}prestashop>statslive_38c50b731f70abc42c8baa3e7399b413'] = 'Desde';
$_MODULE['<{statslive}prestashop>statslive_13aa8652e950bb7c4b9b213e6d8d0dc5'] = 'Página en curso';
$_MODULE['<{statslive}prestashop>statslive_b6f05e5ddde1ec63d992d61144452dfa'] = 'origen';
$_MODULE['<{statslive}prestashop>statslive_ec0fc0100c4fc1ce4eea230c3dc10360'] = 'Indefinido';
$_MODULE['<{statslive}prestashop>statslive_334c4a4c42fdb79d7ebc3e73b517e6f8'] = 'ninguno';
$_MODULE['<{statslive}prestashop>statslive_a55533db46597bee3cd16899c007257e'] = 'No hay visitantes en línea ahora.';
