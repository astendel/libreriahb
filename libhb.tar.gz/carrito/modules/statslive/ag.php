<?php

global $_MODULE;
$_MODULE = array();


$_MODULE['<{statslive}prestashop>statslive_fa55230e9791f2b71322869318a5f00f'] = 'Visitantes en lÃ­nea';
$_MODULE['<{statslive}prestashop>statslive_65b97b824779d02dedaa8f200f3be285'] = 'Mostrar la lita de cliente y visitantes conectados';
$_MODULE['<{statslive}prestashop>statslive_5c948349bdf1a7a77ba54497d019e4ca'] = 'Clientes en lÃ­nea';
$_MODULE['<{statslive}prestashop>statslive_66c4c5112f455a19afde47829df363fa'] = 'Total:';
$_MODULE['<{statslive}prestashop>statslive_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statslive}prestashop>statslive_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{statslive}prestashop>statslive_4351cfebe4b61d8aa5efa1d020710005'] = 'Vista';
$_MODULE['<{statslive}prestashop>statslive_b7a8400dd55cc7c386074220a90cb621'] = 'No hay clentes en lÃ­nea.';
$_MODULE['<{statslive}prestashop>statslive_a12a3079e14ced46e69ba52b8a90b21a'] = 'IP';
$_MODULE['<{statslive}prestashop>statslive_38c50b731f70abc42c8baa3e7399b413'] = 'Desde';
$_MODULE['<{statslive}prestashop>statslive_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referido';
$_MODULE['<{statslive}prestashop>statslive_334c4a4c42fdb79d7ebc3e73b517e6f8'] = 'Ninguno';
$_MODULE['<{statslive}prestashop>statslive_a2c7a04231294d6b38e320ff87b56512'] = 'No hay visitantes en lÃ­nea ahora.';
