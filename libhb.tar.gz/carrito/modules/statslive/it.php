<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statslive}prestashop>statslive_fa55230e9791f2b71322869318a5f00f'] = 'Visitatori online';
$_MODULE['<{statslive}prestashop>statslive_b8a5ea9b6e7f2d0b56fbb18e5b6b9246'] = 'Visualizza l\'elenco dei clienti e dei visitatori online';
$_MODULE['<{statslive}prestashop>statslive_fd42d96861238b1cd5859585c4351eca'] = 'È necessario attivare l\'opzione \"pagine viste per ogni cliente\" nel modulo \"recupero dei dati statistici\" per visualizzare le pagine attualmente viste dai suoi clienti.';
$_MODULE['<{statslive}prestashop>statslive_5c948349bdf1a7a77ba54497d019e4ca'] = 'Clienti online';
$_MODULE['<{statslive}prestashop>statslive_66c4c5112f455a19afde47829df363fa'] = 'Totale:';
$_MODULE['<{statslive}prestashop>statslive_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statslive}prestashop>statslive_49ee3087348e8d44e1feda1917443987'] = 'Nome';
$_MODULE['<{statslive}prestashop>statslive_f88589c3e803217e3f6fe9d8e740e6e8'] = 'Pagina corrente';
$_MODULE['<{statslive}prestashop>statslive_4351cfebe4b61d8aa5efa1d020710005'] = 'Visualizza';
$_MODULE['<{statslive}prestashop>statslive_2fb60e2c82df1e84e827b2f50661403e'] = 'Non ci sono clienti on line.';
$_MODULE['<{statslive}prestashop>statslive_adb831a7fdd83dd1e2a309ce7591dff8'] = 'Ospite';
$_MODULE['<{statslive}prestashop>statslive_a12a3079e14ced46e69ba52b8a90b21a'] = 'IP';
$_MODULE['<{statslive}prestashop>statslive_38c50b731f70abc42c8baa3e7399b413'] = 'Da';
$_MODULE['<{statslive}prestashop>statslive_13aa8652e950bb7c4b9b213e6d8d0dc5'] = 'Pagina corrente';
$_MODULE['<{statslive}prestashop>statslive_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referente';
$_MODULE['<{statslive}prestashop>statslive_ec0fc0100c4fc1ce4eea230c3dc10360'] = 'Indefinito';
$_MODULE['<{statslive}prestashop>statslive_334c4a4c42fdb79d7ebc3e73b517e6f8'] = 'nessuno';
$_MODULE['<{statslive}prestashop>statslive_a55533db46597bee3cd16899c007257e'] = 'Non ci sono visitatori online adesso.';

?>