<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statssearch}prestashop>statssearch_8c3c245232744602822902b97e65d6f9'] = 'Ricerca negozio';
$_MODULE['<{statssearch}prestashop>statssearch_5393c969e2fb0e630e03b993fee091e7'] = 'Mostra quali parole chiave sono state ricercate dai tuoi visitatori';
$_MODULE['<{statssearch}prestashop>statssearch_867343577fa1f33caa632a19543bd252'] = 'parole chiave';
$_MODULE['<{statssearch}prestashop>statssearch_e52e6aa1a43a0187e44f048f658db5f9'] = 'Occorrenze';
$_MODULE['<{statssearch}prestashop>statssearch_fd69c5cf902969e6fb71d043085ddee6'] = 'Risultati';
$_MODULE['<{statssearch}prestashop>statssearch_998e4c5c80f27dec552e99dfed34889a'] = 'Esporta CSV';
$_MODULE['<{statssearch}prestashop>statssearch_df7e8db30f72561b6c3f3941ce88722a'] = 'Nessuna parola chiave cercata più di una volta.';
$_MODULE['<{statssearch}prestashop>statssearch_6b4d88dce7077cd4181a692a1678b60a'] = 'Le prime 10 parole chiave ';
$_MODULE['<{statssearch}prestashop>statssearch_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Altri';

?>