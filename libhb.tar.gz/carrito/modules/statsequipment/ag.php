<?php

global $_MODULE;
$_MODULE = array();


$_MODULE['<{statsequipment}prestashop>statsequipment_719d067b229178f03bcfa1da4ac4dede'] = 'Software';
$_MODULE['<{statsequipment}prestashop>statsequipment_503a1fac5cb1efc3f60a0a318ae7caae'] = 'Mostrar el Software usado por sus visitantes';
$_MODULE['<{statsequipment}prestashop>statsequipment_575e3c9cac82aacd649b1196d845588a'] = 'Plug-ins';
$_MODULE['<{statsequipment}prestashop>statsequipment_e503bccaa7a7649e8b062d692c1620bd'] = 'Cuando se gestionan comercios electronicos, es importante no perder de vista el software utilizado por los visitantes en orden de asegurar que el sitio se muestra de la misma manera para cada uno, y PrestaShop fue creado para ser compatible con la mayorÃ­a de los buscadores recientes y de los sistemas operativos de ordenadores (OS) de la red. Sin embargo, puesto que sabiendo que usted puede terminar agregando caracterÃ­sticas avanzadas a su Web site o aÃºn modificar el cÃ³digo de PrestaShop base, estas adiciones pueden no ser accesibles para todos. Ã‰sa es la razÃ³n por la cual es una buena idea guardar una relaciÃ³n en pestaÃ±as del porcentaje de usuarios para cada tipo de software antes de agregar o de cambiar algo que solamente un nÃºmero limitado de usuarios podrÃ¡ tener acceso.';
$_MODULE['<{statsequipment}prestashop>statsequipment_8ce59076ab4eaa3570ff2a931706d3c1'] = 'Buscador utilizado';
$_MODULE['<{statsequipment}prestashop>statsequipment_eb84ea9e8324beffd94fdeff011edfd7'] = 'Sistema operativo usado';
