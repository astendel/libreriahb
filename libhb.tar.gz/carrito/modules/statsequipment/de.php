<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsequipment}prestashop>statsequipment_719d067b229178f03bcfa1da4ac4dede'] = 'Software';
$_MODULE['<{statsequipment}prestashop>statsequipment_a7b3ac03f9e0f1dabad82e41f6cfed37'] = 'Anzeige der von Ihren Besuchern benutzten Software';
$_MODULE['<{statsequipment}prestashop>statsequipment_dcbcd22b719ba36dad1330178c6bf761'] = 'Bestimmen Sie den Web-Browser-Prozentsatz, den Ihr Kunden nutzt.';
$_MODULE['<{statsequipment}prestashop>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'CSV-Export';
$_MODULE['<{statsequipment}prestashop>statsequipment_dc29a12c359732b223367cb61df2196d'] = 'Bestimmen Sie den Prozentsatz der Betriebssysteme, die Ihre Kunden nutzen.';
$_MODULE['<{statsequipment}prestashop>statsequipment_575e3c9cac82aacd649b1196d845588a'] = 'Plug-ins';
$_MODULE['<{statsequipment}prestashop>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Erklärung';
$_MODULE['<{statsequipment}prestashop>statsequipment_501361472d0528ee07f202297f599d40'] = 'Stellen Sie sicher, dass Ihre Webseite für alle zugänglich ist ';
$_MODULE['<{statsequipment}prestashop>statsequipment_8ebe1665d646cc99d4a80835d1734cad'] = 'Bei der Webseitenverwaltung ist es wichtig, die vom Kunden genutzte Software im Auge zu behalten, um sicher zu gehen, dass die Webseite allen das Gleiche anzeigt. PrestaShop wurde so konzipiert, dass es mit den meisten neueren Webbrowsern und Betriebssystemen kompatibel ist. Falls Sie schließlich jedoch Ihren Webbrowser durch fortgeschrittene Funktionen erweitern oder sogar den PrestaShop Core Code verändern, können diese Zusätze nicht für alle zugänglich sein. Daher ist es angeraten, Tabs auf dem Prozentsatz der Kunden für jede Software-Art zu behalten, bevor Sie etwas hinzufügen oder ändern, was nur einer begrenzten Zahl an Benutzern zugänglich ist.';
$_MODULE['<{statsequipment}prestashop>statsequipment_8ce59076ab4eaa3570ff2a931706d3c1'] = 'Web-Browser-Benutzung';
$_MODULE['<{statsequipment}prestashop>statsequipment_eb84ea9e8324beffd94fdeff011edfd7'] = 'Betriebssystem-Benutzung';

?>