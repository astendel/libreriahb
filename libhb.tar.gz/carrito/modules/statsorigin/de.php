<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsorigin}prestashop>statsorigin_f0b1507c6bdcdefb60a0e6f9b89d4ae8'] = 'Herkunft des Besuchers';
$_MODULE['<{statsorigin}prestashop>statsorigin_ada7786973910e9c8cb95f0450bf55c3'] = 'Anzeige der Webseiten, von denen Ihre Besucher kommen';
$_MODULE['<{statsorigin}prestashop>statsorigin_14542f5997c4a02d4276da364657f501'] = 'Direkt-Link';
$_MODULE['<{statsorigin}prestashop>statsorigin_3edf8ca26a1ec14dd6e91dd277ae1de6'] = 'Herkunft';
$_MODULE['<{statsorigin}prestashop>statsorigin_b5c1b8a326be0d2fb25b3cf6da677d0e'] = 'Hier ist der Prozentsatz der 10 beliebtesten Referrer-Webseiten, über die Besucher zu Ihrem Shop gekommen sind.';
$_MODULE['<{statsorigin}prestashop>statsorigin_998e4c5c80f27dec552e99dfed34889a'] = 'CSV-Export';
$_MODULE['<{statsorigin}prestashop>statsorigin_96b0141273eabab320119c467cdcaf17'] = 'Insgesamt';
$_MODULE['<{statsorigin}prestashop>statsorigin_0bebf95ee829c33f34fde535ed4ed100'] = 'Nur direkte Links';
$_MODULE['<{statsorigin}prestashop>statsorigin_6602bbeb2956c035fb4cb5e844a4861b'] = 'Erklärung';
$_MODULE['<{statsorigin}prestashop>statsorigin_64ae584c62d0992a911d52122ebefc9a'] = 'Was ist eine Referrer-Webseite?';
$_MODULE['<{statsorigin}prestashop>statsorigin_77de261cf4c31a96146bcf1b52fd9856'] = 'Beim Besuch einer Webseite ist der Referrer die URL der vorherigen Webseite, von der ein Link folgte.';
$_MODULE['<{statsorigin}prestashop>statsorigin_d8d034b6911b1ce74bdb2158a14cd287'] = 'Ein Referrer informiert Sie darüber, welche Keywords  Besucher in  Suchmaschinen eingeben, wenn sie zu ihrem Shop kommen wollen, und optimiert damit auch Ihre Werbung im Web.';
$_MODULE['<{statsorigin}prestashop>statsorigin_af19c8da1c414055c960a73d86471119'] = 'Referrer können sein:';
$_MODULE['<{statsorigin}prestashop>statsorigin_a3dec1a06e19a810a9a4884293f666d0'] = 'Jemand, der einen Link zu Ihrem Shop auf seiner Webseite hat';
$_MODULE['<{statsorigin}prestashop>statsorigin_95b90f58e843b56885beabf4802676a9'] = 'Ein Partner, mit dem Sie Links getauscht haben, um die Verkäufe zu erhöhen oder Neukunden anzuziehen';
$_MODULE['<{statsorigin}prestashop>statsorigin_7a82cc29e910ea0c07501d5fe809fd75'] = '10 erste Webseiten';
$_MODULE['<{statsorigin}prestashop>statsorigin_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Andere';

?>