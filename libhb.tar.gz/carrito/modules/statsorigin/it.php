<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsorigin}prestashop>statsorigin_f0b1507c6bdcdefb60a0e6f9b89d4ae8'] = 'Origine visitatori';
$_MODULE['<{statsorigin}prestashop>statsorigin_ada7786973910e9c8cb95f0450bf55c3'] = 'Visualizzare i siti web da cui provengono i tuoi visitatori';
$_MODULE['<{statsorigin}prestashop>statsorigin_14542f5997c4a02d4276da364657f501'] = 'Link diretto';
$_MODULE['<{statsorigin}prestashop>statsorigin_3edf8ca26a1ec14dd6e91dd277ae1de6'] = 'Origine';
$_MODULE['<{statsorigin}prestashop>statsorigin_b5c1b8a326be0d2fb25b3cf6da677d0e'] = 'Ecco la percentuale dei 10 siti più popolari di riferimento dai quali i visitatori hanno raggiunto il tuo negozio.';
$_MODULE['<{statsorigin}prestashop>statsorigin_998e4c5c80f27dec552e99dfed34889a'] = 'Esporta CSV';
$_MODULE['<{statsorigin}prestashop>statsorigin_96b0141273eabab320119c467cdcaf17'] = 'Totale';
$_MODULE['<{statsorigin}prestashop>statsorigin_0bebf95ee829c33f34fde535ed4ed100'] = 'Solo link diretti ';
$_MODULE['<{statsorigin}prestashop>statsorigin_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guida';
$_MODULE['<{statsorigin}prestashop>statsorigin_64ae584c62d0992a911d52122ebefc9a'] = 'Che cosa è un sito web di riferimento?';
$_MODULE['<{statsorigin}prestashop>statsorigin_77de261cf4c31a96146bcf1b52fd9856'] = 'Quando si visita una pagina web, il riferimento è l\'URL della pagina web precedente da cui è stato seguito un link.';
$_MODULE['<{statsorigin}prestashop>statsorigin_d8d034b6911b1ce74bdb2158a14cd287'] = 'Un riferimento consente di sapere quali parole chiave sono state inserite dai visitatori nei motori di ricerca quando hanno cercato di raggiungere il tuo negozio, e anche per ottimizzare la promozione sul web.';
$_MODULE['<{statsorigin}prestashop>statsorigin_af19c8da1c414055c960a73d86471119'] = 'Un riferimento può essere:';
$_MODULE['<{statsorigin}prestashop>statsorigin_a3dec1a06e19a810a9a4884293f666d0'] = 'Qualcuno che mettere un link sul suo  sito web verso il tuo negozio';
$_MODULE['<{statsorigin}prestashop>statsorigin_95b90f58e843b56885beabf4802676a9'] = 'Un partner con cui hai fatto uno scambio di link al fine di aumentare le vendite o attirare nuovi clienti';
$_MODULE['<{statsorigin}prestashop>statsorigin_7a82cc29e910ea0c07501d5fe809fd75'] = 'I primi 10 siti web ';
$_MODULE['<{statsorigin}prestashop>statsorigin_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Altri';

?>