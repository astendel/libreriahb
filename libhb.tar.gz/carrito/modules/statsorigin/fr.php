<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsorigin}prestashop>statsorigin_f0b1507c6bdcdefb60a0e6f9b89d4ae8'] = 'Sites affluents';
$_MODULE['<{statsorigin}prestashop>statsorigin_ada7786973910e9c8cb95f0450bf55c3'] = 'Affiche les sites d\'origine de vos visiteurs';
$_MODULE['<{statsorigin}prestashop>statsorigin_14542f5997c4a02d4276da364657f501'] = 'Lien direct';
$_MODULE['<{statsorigin}prestashop>statsorigin_3edf8ca26a1ec14dd6e91dd277ae1de6'] = 'Origine';
$_MODULE['<{statsorigin}prestashop>statsorigin_b5c1b8a326be0d2fb25b3cf6da677d0e'] = 'Pourcentage des 10 meilleurs sites affluents par lesquels les visiteurs passent pour accéder à votre boutique.';
$_MODULE['<{statsorigin}prestashop>statsorigin_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsorigin}prestashop>statsorigin_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{statsorigin}prestashop>statsorigin_0bebf95ee829c33f34fde535ed4ed100'] = 'Liens directs uniquement';
$_MODULE['<{statsorigin}prestashop>statsorigin_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsorigin}prestashop>statsorigin_64ae584c62d0992a911d52122ebefc9a'] = 'Qu\'est-ce qu\'un site affluent (référant) ?';
$_MODULE['<{statsorigin}prestashop>statsorigin_77de261cf4c31a96146bcf1b52fd9856'] = 'Lorsqu\'un internaute visite une page web, le site affluent est l\'URL du lien qu\'a suivi le visiteur pour accéder à sa page web actuelle.';
$_MODULE['<{statsorigin}prestashop>statsorigin_d8d034b6911b1ce74bdb2158a14cd287'] = 'Un référant vous permet de savoir quels sont les mots clés tapés par les visiteurs dans les moteurs de recherche quand ils tentent d\'aller sur votre boutique; et ainsi d\'optimiser le référencement de votre boutique.';
$_MODULE['<{statsorigin}prestashop>statsorigin_af19c8da1c414055c960a73d86471119'] = 'Un référant peut être :';
$_MODULE['<{statsorigin}prestashop>statsorigin_a3dec1a06e19a810a9a4884293f666d0'] = 'Quelqu\'un qui a mis un lien de votre boutique sur son site';
$_MODULE['<{statsorigin}prestashop>statsorigin_95b90f58e843b56885beabf4802676a9'] = 'Un partenaire avec lequel vous avez fait un échange de lien visant à rapporter des ventes ou attirer de nouveaux clients';
$_MODULE['<{statsorigin}prestashop>statsorigin_7a82cc29e910ea0c07501d5fe809fd75'] = '10 premiers sites';
$_MODULE['<{statsorigin}prestashop>statsorigin_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Autres';
