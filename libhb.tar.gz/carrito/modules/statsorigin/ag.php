<?php

global $_MODULE;
$_MODULE = array();


$_MODULE['<{statsorigin}prestashop>statsorigin_f0b1507c6bdcdefb60a0e6f9b89d4ae8'] = 'Origen del visitante';
$_MODULE['<{statsorigin}prestashop>statsorigin_b860f6548aca73c7da23337804e6022e'] = 'Mostrar las Web de origen de sus visitantes';
$_MODULE['<{statsorigin}prestashop>statsorigin_3edf8ca26a1ec14dd6e91dd277ae1de6'] = 'Origen';
$_MODULE['<{statsorigin}prestashop>statsorigin_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{statsorigin}prestashop>statsorigin_0bebf95ee829c33f34fde535ed4ed100'] = 'Solamente vinculos directos';
$_MODULE['<{statsorigin}prestashop>statsorigin_9465e6ab1ee03dea7b6c1eefdab8aa4b'] = '10 primeras webs';
$_MODULE['<{statsorigin}prestashop>statsorigin_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Otros';
