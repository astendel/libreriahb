<?php

global $_MODULE;
$_MODULE = array();


$_MODULE['<{productcomments}prestashop>productcomments_b91c4e8b229a399a3bc911d352524a9b'] = 'Comentario de producto';
$_MODULE['<{productcomments}prestashop>productcomments_eb4783ce47d29a12b944635fc255893f'] = 'Permitir a los usuarios registra comentarios acerca del producto';
$_MODULE['<{productcomments}prestashop>productcomments_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmar';
$_MODULE['<{productcomments}prestashop>productcomments_c888438d14855d7d96a2724ee9c306bd'] = 'Ajustes actualizados';
$_MODULE['<{productcomments}prestashop>productcomments_0a36c5f3ea6825804e6b4314c4084a12'] = 'Moderar comentarios';
$_MODULE['<{productcomments}prestashop>productcomments_519532ca486f468a9dd44232e7b0cafa'] = 'Se requiere validaciÃ³n';
$_MODULE['<{productcomments}prestashop>productcomments_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Habilitado';
$_MODULE['<{productcomments}prestashop>productcomments_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deshabilitado';
$_MODULE['<{productcomments}prestashop>productcomments_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{productcomments}prestashop>productcomments_06df33001c1d7187fdd81ea1f5b277aa'] = 'AcciÃ³n';
$_MODULE['<{productcomments}prestashop>productcomments_a517747c3d12f99244ae598910d979c5'] = 'Autor';
$_MODULE['<{productcomments}prestashop>productcomments_0be8406951cdfda82f00f79328cf4efc'] = 'Comentario';
$_MODULE['<{productcomments}prestashop>productcomments_c4408d335012a56ff58937d78050efad'] = 'Aceptar';
$_MODULE['<{productcomments}prestashop>productcomments_f2a6c498fb90ee345d997f888fce3b18'] = 'Eliminar';
$_MODULE['<{productcomments}prestashop>productcomments_0e1a03b7b26ffce9312556aa4de91a00'] = 'No hay cometarios a validar';
$_MODULE['<{productcomments}prestashop>productcomments_0048bfb5ec7540fce6a8262321abb68b'] = 'Criterios de los comentarios';
$_MODULE['<{productcomments}prestashop>productcomments_5425e30a4f2d17eebb3ccbc8d9e4b879'] = 'Criterio del comentario';
$_MODULE['<{productcomments}prestashop>productcomments_ec211f7c20af43e742bf2570c3cb84f9'] = 'AÃ±adir';
$_MODULE['<{productcomments}prestashop>productcomments_549f9fb7be6d7edda6c5560f4ec30be4'] = 'Cree un nuevo criterio de clasificaciÃ³n para sus productos.';
$_MODULE['<{productcomments}prestashop>productcomments_dd33a09f24a2e9e889b7f1f1a0255c22'] = 'Una vez creado, debe activarlo para los productos deseados con la forma abajo.';
$_MODULE['<{productcomments}prestashop>productcomments_daa1f0640f2e6759e4b4f2b981b21285'] = 'Sea consciente que los criterios son independientes en cada idioma.';
$_MODULE['<{productcomments}prestashop>productcomments_21a512e9d635e82fc7c7077fc880988b'] = 'Criterio';
$_MODULE['<{productcomments}prestashop>productcomments_e04d057b0b4f26f6d67294bb953fa84b'] = 'Criterios de productos';
$_MODULE['<{productcomments}prestashop>productcomments_5d4b6d89c4c760deacf872899482ff06'] = 'Seleccione los criterios de clasificaciÃ³n que corresponden a cada producto. Usted puede seleccionar criterios mÃºltiples pulsando la tecla del Ctrl.';
$_MODULE['<{productcomments}prestashop>productcomments_deb10517653c255364175796ace3553f'] = 'Producto';
$_MODULE['<{productcomments}prestashop>productcomments_92c8811185c56998dfbcbdd30ad649d3'] = 'Criterios de clasificaciÃ³n';
$_MODULE['<{productcomments}prestashop>productcomments_7b2f2ea0f690ef3c2fc9bba0e4bfbc4c'] = 'Comentario de texto no vÃ¡lido para publicaciÃ³n.';
$_MODULE['<{productcomments}prestashop>productcomments_06316a7f66070d83b0be475d1548d5ad'] = 'Se ha producido un error al guardar su comentario.';
$_MODULE['<{productcomments}prestashop>productcomments_ad4ec284804b5d44a3e6de6c851e2731'] = 'Comentario publicado con Ã©xito.';
$_MODULE['<{productcomments}prestashop>productcomments_e1549cfa9780c9c706f9ea8fdc25e441'] = 'En espera de la validaciÃ³n del moderador.';
$_MODULE['<{productcomments}prestashop>productcomments_6bf852d9850445291f5e9d4740ac7b50'] = 'Se requiere el texto del comentario.';
$_MODULE['<{productcomments}prestashop>productcomments_7c3b0e9898b88deee7ea75aafd2e37e2'] = 'Grado medio';
$_MODULE['<{productcomments}prestashop>productcomments_b1897515d548a960afe49ecf66a29021'] = 'Promedio';
$_MODULE['<{productcomments}prestashop>productcomments_5da618e8e4b89c66fe86e32cdafde142'] = 'Desde';
$_MODULE['<{productcomments}prestashop>productcomments_08621d00a3a801b9159a11b8bbd69f89'] = 'No hay comentarios de clientes por ahora.';
$_MODULE['<{productcomments}prestashop>productcomments_c3edcf2cedbd4ce230fd6d4ea8915718'] = 'Agregar comentario';
$_MODULE['<{productcomments}prestashop>productcomments_94966d90747b97d1f0f206c98a8b1ac3'] = 'EnvÃ­ar';
$_MODULE['<{productcomments}prestashop>productcomments_75b4e58a3954686f84e68e2eafb730d9'] = 'Solamente el usuario registrado puede introducir comentarios. ';
$_MODULE['<{productcomments}prestashop>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comentarios';
