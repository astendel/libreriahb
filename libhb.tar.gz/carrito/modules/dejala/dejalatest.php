<?php
//Indispensable ??
class DejalaTest
{
	public $dejalaConfig;
	// 'TEST' or 'PROD'
	public		$mode = "TEST";
	
	
	
	
}

$djlTest = new DejalaTest();




?>