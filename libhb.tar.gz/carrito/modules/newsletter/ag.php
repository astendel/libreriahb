<?php

global $_MODULE;
$_MODULE = array();


$_MODULE['<{newsletter}prestashop>newsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'BoletÃ­n de Noticias';
$_MODULE['<{newsletter}prestashop>newsletter_804a924e464fd21ed92f820224c4091d'] = 'Genera un fichero .csv para mailing masivo';
$_MODULE['<{newsletter}prestashop>newsletter_c3987e4cac14a8456515f0d200da04ee'] = 'Todos los paises';
$_MODULE['<{newsletter}prestashop>newsletter_fa01fd956e87307bce4c90a0de9b0437'] = 'Pais del Cliente';
$_MODULE['<{newsletter}prestashop>newsletter_c0859b0a5241dff468da2a9a93c3284f'] = 'Aplica un filtro por pais del cliente.';
$_MODULE['<{newsletter}prestashop>newsletter_f2ab5e3c58e5dbe15615f0060d036956'] = 'Suscritos al boletÃ­n';
$_MODULE['<{newsletter}prestashop>newsletter_99006a61d48499231e1be92241cf772a'] = 'Filtro de suscriptores al boletÃ­n de noticias.';
$_MODULE['<{newsletter}prestashop>newsletter_7e3a51a56ddd2846e21c33f05e0aea6f'] = 'Todos los clientes';
$_MODULE['<{newsletter}prestashop>newsletter_39f7a3e2b56e9bfd753ba6325533a127'] = 'Suscritos';
$_MODULE['<{newsletter}prestashop>newsletter_011d8c5d94f729f013963d856cd78745'] = 'No Suscritos';
$_MODULE['<{newsletter}prestashop>newsletter_793ee192a9124cd6f529460eef17d3e5'] = 'No Suscritos';
$_MODULE['<{newsletter}prestashop>newsletter_7b15c043d66fecc45c8752592aa38e38'] = 'OpciÃ³n de filtrar los suscriptores';
$_MODULE['<{newsletter}prestashop>newsletter_cbfbc813d2b33a2c264e878e31cf2cc0'] = 'No hay clientes con estos filtros aplicados!';
$_MODULE['<{newsletter}prestashop>newsletter_f8db2243069bf76570a084ea11d1c667'] = 'El fichero .csv ha sido exportado correctamente';
$_MODULE['<{newsletter}prestashop>newsletter_55caa4828d4e935c2ba9f1558f1c4edd'] = 'clientes encontrados';
$_MODULE['<{newsletter}prestashop>newsletter_48e3d5f66961b621c78f709afcd7d437'] = 'Descargar el fichero';
$_MODULE['<{newsletter}prestashop>newsletter_d04e6ff103ecd59c2e24d89137fd772c'] = 'Error: no puedo escribir en';
$_MODULE['<{newsletter}prestashop>newsletter_8d550e9bf69bfc7a09be6eeb1622ae23'] = 'Hay dos clases de este mÃ³dulo:';
$_MODULE['<{newsletter}prestashop>newsletter_23e8f8a55548b88bfbdcd1f6ba26a010'] = 'Las personas que hayan suscrito utilizando el bloque noticias en la tienda.';
$_MODULE['<{newsletter}prestashop>newsletter_9f1f1e7064f60721a843c1006f4c0569'] = 'Esta serÃ¡ una lista de direcciones de correo electrÃ³nico para las personas que visiten su tienda y no se convierta en clientes, pero que desean obtener su boletÃ­n informativo. Use  \\\"Newsletter Suscriptores de exportaciÃ³n\\\" mÃ¡s abajo y generarÃ¡ una. CSV sobre la base de los usuarios del  BlockNewsletter datos.';
$_MODULE['<{newsletter}prestashop>newsletter_74ca54506cdbc82e3aa763ba91b8fa39'] = '	rnLos clientes que han usado el bloque  para recibir un boletÃ­n en su perfil de cliente.';
$_MODULE['<{newsletter}prestashop>newsletter_3387c45f70871b981a14bbbdd73a5646'] = 'Clientes que desea enviar un boletÃ­n informativo.';
$_MODULE['<{newsletter}prestashop>newsletter_b192ab83a19105bbf1e2d1fab548249a'] = 'Exportar susbcritos al boletin de noticias';
$_MODULE['<{newsletter}prestashop>newsletter_a60401e616125189d78605b2ddd7ff45'] = 'Generar un archivo. CSV BlockNewsletter sobre la base de datos de suscriptores.';
$_MODULE['<{newsletter}prestashop>newsletter_dbb392a2dc9b38722e69f6032faea73e'] = 'Exportar un fichero .csv';
$_MODULE['<{newsletter}prestashop>newsletter_4713ef5f2d6fc1e8f088c850e696a04b'] = 'Exportar clientes';
$_MODULE['<{newsletter}prestashop>newsletter_507db84221164a388b0c9f3991061ae0'] = 'Generar un archivo. CSV archivo de datos de la cuenta de clientes';
