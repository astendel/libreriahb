<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{fianetsceau}prestashop>fianetsceau_21d574c0b27fc6bebc399be75502d84d'] = 'FIA-NET Sceau de Confiance';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_76c3b678f626c3858c3c98baac90c7ac'] = 'Transformez vos visiteurs en acheteurs en créant la confiance sur votre site';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_32c355617b8730b1603e31d144513890'] = 'Veuillez renseigner votre clé privée';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_59dd48942de548b075014fe901bfae1b'] = 'Veuillez renseigner l\'ID de votre site';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Paramètres mis à jour avec succès';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_380b4179d36bce6ca862459a43b217b5'] = 'Pour vous inscrire, rendez-vous sur:';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_592fcfe937f6d58f70d0918ef6373afa'] = 'le site internet de Fia-Net';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_ee56be2890222bce04455a34055fd107'] = 'L\'id de votre site';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_f0f5fac9602d88bc27f0edf960dda8b8'] = 'Exemple :';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_7b00d0388fa5d48b7b00e4f71e4d71d0'] = '(nombres seulement)';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_d2560860c51f895a9871741f0805c39e'] = 'Clé privée';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_15e8f5f1bb8a1c0cd63bb832412799b1'] = 'Clé privée communiquée par Fia-Net';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_650be61892bf690026089544abbd9d26'] = 'Mode';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_0cbc6611f5540bd0809a388dc95a615b'] = 'Test';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_756d97bb256b8580d4d71ee0c547804e'] = 'Production';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_b17f3f4dcf653a5776792498a9b44d6a'] = 'Mettre à jour';
