<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{fianetsceau}prestashop>fianetsceau_21d574c0b27fc6bebc399be75502d84d'] = 'FIA-NET Vertrauenssiegel';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_76c3b678f626c3858c3c98baac90c7ac'] = 'Machen Sie Ihre Besucher zu Käufern durch Vertrauensbildung in Ihre Webseite';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_32c355617b8730b1603e31d144513890'] = 'Bitte füllen Sie Ihr geheimes Schlüsselfeld aus';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_59dd48942de548b075014fe901bfae1b'] = 'Bitte geben Sie Ihre Seiten-ID ein';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguration aktualisiert';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_380b4179d36bce6ca862459a43b217b5'] = 'Um sich anzumelden, melden Sie sich ab:';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_592fcfe937f6d58f70d0918ef6373afa'] = 'Fia-Net Website';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_ee56be2890222bce04455a34055fd107'] = 'Ihre Seiten-ID';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_f0f5fac9602d88bc27f0edf960dda8b8'] = 'Beispiel:';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_7b00d0388fa5d48b7b00e4f71e4d71d0'] = '(Nur Zahlen)';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_d2560860c51f895a9871741f0805c39e'] = 'geheimer Schlüssel';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_15e8f5f1bb8a1c0cd63bb832412799b1'] = 'geheimer Schlüssel, den Sie von Fia-Net erhalten haben';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_650be61892bf690026089544abbd9d26'] = 'Modus';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_0cbc6611f5540bd0809a388dc95a615b'] = 'Test';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_756d97bb256b8580d4d71ee0c547804e'] = 'Betrieb';
$_MODULE['<{fianetsceau}prestashop>fianetsceau_b17f3f4dcf653a5776792498a9b44d6a'] = 'Aktualisierungseinstellungen';

?>