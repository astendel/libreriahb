<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscarrier}prestashop>statscarrier_2e6774abc54cb13cef2c5bfd5a2cb463'] = 'Verteilung der Lieferanten';
$_MODULE['<{statscarrier}prestashop>statscarrier_ca0e2bcc96175be91d54e4efb1b32053'] = 'Zeigt die Verteilung der Lieferanten an';
$_MODULE['<{statscarrier}prestashop>statscarrier_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Alle';
$_MODULE['<{statscarrier}prestashop>statscarrier_d7778d0c64b6ba21494c97f77a66885a'] = 'Filter';
$_MODULE['<{statscarrier}prestashop>statscarrier_0bed2833289bf7aae607f86b0750101c'] = 'Diese Grafik zeigt die Verteilung der Lieferanten für Ihre Bestellung an. Sie können sie auch auf einen Bestellstatus begrenzen.';
$_MODULE['<{statscarrier}prestashop>statscarrier_998e4c5c80f27dec552e99dfed34889a'] = 'CSV-Export';
$_MODULE['<{statscarrier}prestashop>statscarrier_07701328e4cdbd1c145f234f136892b5'] = 'Keine gültigen Bestellungen für diesen Zeitraum.';
$_MODULE['<{statscarrier}prestashop>statscarrier_ca190d96c8c6f00f57f5e572708253fb'] = 'Prozentsatz der Bestellungen pro Lieferant';

?>