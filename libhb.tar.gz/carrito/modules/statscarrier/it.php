<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscarrier}prestashop>statscarrier_2e6774abc54cb13cef2c5bfd5a2cb463'] = 'Ripartizione per corriere';
$_MODULE['<{statscarrier}prestashop>statscarrier_ca0e2bcc96175be91d54e4efb1b32053'] = 'Mostra la ripartizione per corrieri ';
$_MODULE['<{statscarrier}prestashop>statscarrier_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Tutto';
$_MODULE['<{statscarrier}prestashop>statscarrier_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtro';
$_MODULE['<{statscarrier}prestashop>statscarrier_0bed2833289bf7aae607f86b0750101c'] = 'Questo grafico rappresenta la  ripartizione per corriere dei tuoi ordini. È inoltre possibile limitare a uno stato di ordine.';
$_MODULE['<{statscarrier}prestashop>statscarrier_998e4c5c80f27dec552e99dfed34889a'] = 'Esporta CSV';
$_MODULE['<{statscarrier}prestashop>statscarrier_07701328e4cdbd1c145f234f136892b5'] = 'Nessun ordine valido per questo periodo.';
$_MODULE['<{statscarrier}prestashop>statscarrier_ca190d96c8c6f00f57f5e572708253fb'] = 'Percentuale degli ordini per corriere';

?>