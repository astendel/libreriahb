<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ekomi}prestashop>ekomi_c0858307dfd3d91768c79ec116820b60'] = 'eKomi';
$_MODULE['<{ekomi}prestashop>ekomi_d245187b3591f5f6f723ece2217bb637'] = 'Aggiunge un blocco eKomi';
$_MODULE['<{ekomi}prestashop>ekomi_5f8f22b8cdbaeee8cf857673a9b6ba20'] = 'directory';
$_MODULE['<{ekomi}prestashop>ekomi_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Conferma';
$_MODULE['<{ekomi}prestashop>ekomi_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{ekomi}prestashop>ekomi_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{ekomi}prestashop>ekomi_597b9cfa17df5ac4e2a4b1f4b6de347a'] = 'configurazione eKomi';
$_MODULE['<{ekomi}prestashop>ekomi_c4fda5e26d4854b8718850c90694a54c'] = 'e-mail eKomi ';
$_MODULE['<{ekomi}prestashop>ekomi_c48c140af813696592daafbabe6d8b9f'] = 'script eKomi';
$_MODULE['<{ekomi}prestashop>ekomi_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivo';
$_MODULE['<{ekomi}prestashop>ekomi_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{ekomi}prestashop>ekomi_ced21fe73878a0139d427ab2927f6772'] = 'Mostrare o non mostrare il blocco (gli ordini verranno inviati a eKomi se si sceglie di nascondere o visualizzare il blocco).';
$_MODULE['<{ekomi}prestashop>ekomi_6a794dc942b2e8b4716dbc654e83d094'] = 'Si prega di compilare il modulo con i dati che eKomi vi dà.';
$_MODULE['<{ekomi}prestashop>ekomi_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';

?>