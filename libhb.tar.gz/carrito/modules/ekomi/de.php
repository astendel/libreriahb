<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ekomi}prestashop>ekomi_c0858307dfd3d91768c79ec116820b60'] = 'eKomi';
$_MODULE['<{ekomi}prestashop>ekomi_d245187b3591f5f6f723ece2217bb637'] = 'Fügt einen eKomi-Block hinzu';
$_MODULE['<{ekomi}prestashop>ekomi_5f8f22b8cdbaeee8cf857673a9b6ba20'] = 'Pfad';
$_MODULE['<{ekomi}prestashop>ekomi_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Bestätigung';
$_MODULE['<{ekomi}prestashop>ekomi_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{ekomi}prestashop>ekomi_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{ekomi}prestashop>ekomi_597b9cfa17df5ac4e2a4b1f4b6de347a'] = 'eKomi-Konfiguration';
$_MODULE['<{ekomi}prestashop>ekomi_c4fda5e26d4854b8718850c90694a54c'] = 'eKomi E-Mail';
$_MODULE['<{ekomi}prestashop>ekomi_c48c140af813696592daafbabe6d8b9f'] = 'eKomi-Skript';
$_MODULE['<{ekomi}prestashop>ekomi_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{ekomi}prestashop>ekomi_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{ekomi}prestashop>ekomi_ced21fe73878a0139d427ab2927f6772'] = 'Block anzeigen, oder verstecken. Bestellungen werden in jedem Fall an eKomi gesendet.';
$_MODULE['<{ekomi}prestashop>ekomi_6a794dc942b2e8b4716dbc654e83d094'] = 'Bitte füllen Sie das Formular mit den Daten aus, die Sie von eKomi bekommen.';
$_MODULE['<{ekomi}prestashop>ekomi_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';

?>