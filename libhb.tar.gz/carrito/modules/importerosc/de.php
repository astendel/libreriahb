<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{importerosc}prestashop>importerosc_e273168c3697c35b8c737d14b1a5fb26'] = 'osCommerce Importer';
$_MODULE['<{importerosc}prestashop>importerosc_f4a344f88bab7b04a73077bafc8a0187'] = 'Mit diesem Modul können Sie von osCommerce nach Prestashop importieren';
$_MODULE['<{importerosc}prestashop>importerosc_a410107bacc21de421c07f0162f40878'] = 'Standard osCommerce Sprache:';
$_MODULE['<{importerosc}prestashop>importerosc_6325b420c7e3747295ebc4265ca5ebf5'] = 'Standard osCommerce Währung:';
$_MODULE['<{importerosc}prestashop>importerosc_3128e575f57c8bff6950eb946748318a'] = 'Shop URL:';
$_MODULE['<{importerosc}prestashop>importerosc_f106e79e646e4262fae765f77db9ca91'] = 'Root-Pfad für Ihre osCommerce Seite angeben';
$_MODULE['<{importerosc}prestashop>importerosc_a89a64592edf58aee0fc749735902cea'] = 'Bitte wählen Sie eine Standardsprache';
$_MODULE['<{importerosc}prestashop>importerosc_375e6e17d4bd18a5163d3a7d13b80b4b'] = 'Bitte wählen Sie eine Standardwährung';
$_MODULE['<{importerosc}prestashop>importerosc_294f0969b5f80f1bae24a7183eb338d5'] = 'Bitte stellen Sie Ihre Shop URL ein';
$_MODULE['<{importerosc}prestashop>importerosc_86545d77ce5790e924190d9b5a7ac1b6'] = 'Standardgruppe OS Commerce';
$_MODULE['<{importerosc}prestashop>importerosc_9aa1b03934893d7134a660af4204f2a9'] = 'Server';
$_MODULE['<{importerosc}prestashop>importerosc_770b2f7556eecbe5000cfcbddc9f9885'] = '(z.B. mysql.mydomain.com)';
$_MODULE['<{importerosc}prestashop>importerosc_8f9bfe9d1345237cb3b2b205864da075'] = 'Benutzer';
$_MODULE['<{importerosc}prestashop>importerosc_dc647eb65e6711e155375218212b3964'] = 'Kennwort';
$_MODULE['<{importerosc}prestashop>importerosc_14ae0ea02f571a833786d13d9ca6a897'] = '(Kennwort kann leer sein)';
$_MODULE['<{importerosc}prestashop>importerosc_e307db07b3975fef922a80d07455ee5e'] = 'Datenbank';
$_MODULE['<{importerosc}prestashop>importerosc_dac130bdd2c5492a8108a4145bd9f04a'] = 'Datenbank-Präfix';
$_MODULE['<{importerosc}prestashop>importerosc_6bdc02625540b5264cffe801c37a82dd'] = '(Das Präfix ist optional. Wenn alle Ihre Datenbank-Präfixe mit \"pref_\" beginnen, lautet das Präfix \"pref_\")';
$_MODULE['<{importerosc}prestashop>importerosc_4685343b5e2e0f0fbee63dddafde693f'] = 'Sie versuchen Kategorien zu importieren, welche in Ihrer osCommerce Datenbank keiner Ebene zugewiesen sind. Sie müssen dieses Feld angeben, um mit dem Import der Kategorien fortzufahren.';
$_MODULE['<{importerosc}prestashop>importerosc_16f35420186575c2a1d9c0b59edf6ad3'] = 'Klicken Sie auf hinzufügen und berechnen Sie die Ebene.';
$_MODULE['<{importerosc}prestashop>importerosc_fced104d747e0855ceff3020653104ab'] = 'Ebene ist berechnet und erstellt worden, Sie können fortfahren.';
$_MODULE['<{importerosc}prestashop>importerosc_b405d0bebeedbdc1773a44ac36b8ffc4'] = 'Es wird dringend empfohlen eine Sicherung Ihrer Datenbank zu erstellen, bevor Sie fortfahren. Haben Sie eine Sicherung erstellt ?';
$_MODULE['<{importerosc}prestashop>importerosc_9f95fc55011203d91d50a0ed512f805f'] = 'Table konnte nicht geändert werden.';

?>