<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{importerosc}prestashop>importerosc_e273168c3697c35b8c737d14b1a5fb26'] = 'Importer osCommerce';
$_MODULE['<{importerosc}prestashop>importerosc_f4a344f88bab7b04a73077bafc8a0187'] = 'Este módulo permite importar su tienda OsCommerce';
$_MODULE['<{importerosc}prestashop>importerosc_a410107bacc21de421c07f0162f40878'] = 'Idioma por defecto de osCommerce:';
$_MODULE['<{importerosc}prestashop>importerosc_6325b420c7e3747295ebc4265ca5ebf5'] = 'Moneda por defecto de osCommerce:';
$_MODULE['<{importerosc}prestashop>importerosc_3128e575f57c8bff6950eb946748318a'] = 'Url de la tienda:';
$_MODULE['<{importerosc}prestashop>importerosc_f106e79e646e4262fae765f77db9ca91'] = 'Especificar la URL de su sitio oscommerce';
$_MODULE['<{importerosc}prestashop>importerosc_a89a64592edf58aee0fc749735902cea'] = 'Por favor, seleccione un idioma por defecto';
$_MODULE['<{importerosc}prestashop>importerosc_375e6e17d4bd18a5163d3a7d13b80b4b'] = 'Por favor seleccione una moneda por defecto';
$_MODULE['<{importerosc}prestashop>importerosc_294f0969b5f80f1bae24a7183eb338d5'] = 'Por favor, establezca la URL de su tienda';
$_MODULE['<{importerosc}prestashop>importerosc_86545d77ce5790e924190d9b5a7ac1b6'] = 'Sistema operativo por defecto Grupo de Comercio';
$_MODULE['<{importerosc}prestashop>importerosc_9aa1b03934893d7134a660af4204f2a9'] = 'Servidor';
$_MODULE['<{importerosc}prestashop>importerosc_770b2f7556eecbe5000cfcbddc9f9885'] = '(ej: mysql.midominio.com)';
$_MODULE['<{importerosc}prestashop>importerosc_8f9bfe9d1345237cb3b2b205864da075'] = 'Usuario';
$_MODULE['<{importerosc}prestashop>importerosc_dc647eb65e6711e155375218212b3964'] = 'Password';
$_MODULE['<{importerosc}prestashop>importerosc_14ae0ea02f571a833786d13d9ca6a897'] = '(el password puede estar vacio)';
$_MODULE['<{importerosc}prestashop>importerosc_e307db07b3975fef922a80d07455ee5e'] = 'Base de datos';
$_MODULE['<{importerosc}prestashop>importerosc_dac130bdd2c5492a8108a4145bd9f04a'] = 'Prefijo de la base de datos';
$_MODULE['<{importerosc}prestashop>importerosc_6bdc02625540b5264cffe801c37a82dd'] = '(El prefijo es opcional. Si todas las tablas de la base de datos comienzan con \"pref_\" ese es su prefijo)';
$_MODULE['<{importerosc}prestashop>importerosc_4685343b5e2e0f0fbee63dddafde693f'] = 'Usted está tratando de importar las categorías y hemos detectado que su base de datos oscommerce no tiene el campo \"nivel\" en la tabla categoria . Usted debe tener este campo para continuar con la importación de las categorías.';
$_MODULE['<{importerosc}prestashop>importerosc_16f35420186575c2a1d9c0b59edf6ad3'] = 'Click para añadir y calcular el campo \"nivel\"';
$_MODULE['<{importerosc}prestashop>importerosc_fced104d747e0855ceff3020653104ab'] = 'El campo NIVEL ha sido creado y calculado, ahora puede continuar';
$_MODULE['<{importerosc}prestashop>importerosc_b405d0bebeedbdc1773a44ac36b8ffc4'] = 'Es altamente recomendable que haga un backup de su base de datos antes de continuar. Ha hecho un backup?';
$_MODULE['<{importerosc}prestashop>importerosc_9f95fc55011203d91d50a0ed512f805f'] = 'No se puede ALTERAR LA TABLA';
