<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{importerosc}prestashop>importerosc_e273168c3697c35b8c737d14b1a5fb26'] = 'Import OsCommerce';
$_MODULE['<{importerosc}prestashop>importerosc_f4a344f88bab7b04a73077bafc8a0187'] = 'Ce module permet d\'importer votre boutique OsCommerce dans prestashop';
$_MODULE['<{importerosc}prestashop>importerosc_a410107bacc21de421c07f0162f40878'] = 'Langue par défaut d\'osCommerce';
$_MODULE['<{importerosc}prestashop>importerosc_6325b420c7e3747295ebc4265ca5ebf5'] = 'Monnaie par défaut d\'osCommerce';
$_MODULE['<{importerosc}prestashop>importerosc_3128e575f57c8bff6950eb946748318a'] = 'Url de votre boutique :';
$_MODULE['<{importerosc}prestashop>importerosc_f106e79e646e4262fae765f77db9ca91'] = 'Indiquez l\'URL racine de votre site oscommerce';
$_MODULE['<{importerosc}prestashop>importerosc_a89a64592edf58aee0fc749735902cea'] = 'Merci de choisir une langue par défaut';
$_MODULE['<{importerosc}prestashop>importerosc_375e6e17d4bd18a5163d3a7d13b80b4b'] = 'Merci de choisir la devise par défaut';
$_MODULE['<{importerosc}prestashop>importerosc_294f0969b5f80f1bae24a7183eb338d5'] = 'Merci de choisir l\'url de la boutique';
$_MODULE['<{importerosc}prestashop>importerosc_86545d77ce5790e924190d9b5a7ac1b6'] = 'Group par défaut OsCommerce';
$_MODULE['<{importerosc}prestashop>importerosc_9aa1b03934893d7134a660af4204f2a9'] = 'Serveur';
$_MODULE['<{importerosc}prestashop>importerosc_770b2f7556eecbe5000cfcbddc9f9885'] = '(Ex: mysql.mydomain.com)';
$_MODULE['<{importerosc}prestashop>importerosc_8f9bfe9d1345237cb3b2b205864da075'] = 'Utilisateur';
$_MODULE['<{importerosc}prestashop>importerosc_dc647eb65e6711e155375218212b3964'] = 'Mot de passe';
$_MODULE['<{importerosc}prestashop>importerosc_14ae0ea02f571a833786d13d9ca6a897'] = '(Mot de passe peut être vide)';
$_MODULE['<{importerosc}prestashop>importerosc_e307db07b3975fef922a80d07455ee5e'] = 'Base de données';
$_MODULE['<{importerosc}prestashop>importerosc_dac130bdd2c5492a8108a4145bd9f04a'] = 'Préfixe base de données';
$_MODULE['<{importerosc}prestashop>importerosc_6bdc02625540b5264cffe801c37a82dd'] = '(Le préfixe est optionnel. Si toute votre base de données commence par \"pref_\", votre préfixe est \"pref_\")';
$_MODULE['<{importerosc}prestashop>importerosc_4685343b5e2e0f0fbee63dddafde693f'] = 'Vous essayez d\'importer des catégories et nous avons détecté que votre base de données osCommerce n\'ont pas le champs \"niveau\" dans la table catégorie. Vous devez avoir ce champs pour continuer l\'importation de catégories.';
$_MODULE['<{importerosc}prestashop>importerosc_16f35420186575c2a1d9c0b59edf6ad3'] = 'Cliquez ici pour ajouter et de calculer le champs niveau';
$_MODULE['<{importerosc}prestashop>importerosc_fced104d747e0855ceff3020653104ab'] = 'Le champ \"niveau\" a été créé et calculé, vous pouvez continuer';
$_MODULE['<{importerosc}prestashop>importerosc_b405d0bebeedbdc1773a44ac36b8ffc4'] = 'Il est fortement recommandé de sauvegarder votre base de données avant de continuer. Avez-vous fait une sauvegarde?';
$_MODULE['<{importerosc}prestashop>importerosc_9f95fc55011203d91d50a0ed512f805f'] = 'Impossible de \"ALTER TABLE\"';
