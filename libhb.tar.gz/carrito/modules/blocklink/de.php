<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklink}prestashop>blocklink_fc738410141e4ec0c0319a81255a1431'] = 'Linkblock';
$_MODULE['<{blocklink}prestashop>blocklink_baa2ae9622a47c3217d725d1537e5187'] = 'Fügt einen Block mit weiteren Links hinzu';
$_MODULE['<{blocklink}prestashop>blocklink_d98d5daaf408b77b05a2eeb6ae88d6df'] = 'Sind Sie sicher, dass Sie alle Ihre Links löschen wollen?';
$_MODULE['<{blocklink}prestashop>blocklink_fe3f38c46c80813d94b6775299e59f13'] = 'Sie müssen alle Felder ausfüllen';
$_MODULE['<{blocklink}prestashop>blocklink_9394bb34611399534ffac4f0ece96b7f'] = 'Falsche URL';
$_MODULE['<{blocklink}prestashop>blocklink_3da9d5745155a430aac6d7de3b6de0c8'] = 'Der Link ist erfolgreich hinzugefügt worden';
$_MODULE['<{blocklink}prestashop>blocklink_898536ebd630aa3a9844e9cd9d1ebb9b'] = 'Ein Fehler ist bei der Link-Erstellung aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_ce9beec1b47458523d46274adfd2acee'] = 'Ein Fehler ist bei der Link-Aktualisierung aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_7a7e3a8d8aefcb1d31b4fdfa1bdf9ee4'] = 'Der Link ist erfolgreich aktualisiert worden';
$_MODULE['<{blocklink}prestashop>blocklink_b18032737875f7947443c98824103a1f'] = 'Das Feld \"Titel\" darf nicht leer bleiben';
$_MODULE['<{blocklink}prestashop>blocklink_43b38b9a2fe65059bed320bd284047e3'] = 'Das Feld \"Titel\" ist ungültig';
$_MODULE['<{blocklink}prestashop>blocklink_eb74914f2759760be5c0a48f699f8541'] = 'Ein Fehler ist bei der Titel-Aktualisierung aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_5c0f7e2db8843204f422a369f2030b37'] = 'Der Blocktitel ist erfolgreich aktualisiert worden';
$_MODULE['<{blocklink}prestashop>blocklink_5d73d4c0bcb035a1405e066eb0cdf832'] = 'Ein Fehler ist beim Löschen des Links aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_9bbcafcc85be214aaff76dffb8b72ce9'] = 'Der Link ist erfolgreich gelöscht worden';
$_MODULE['<{blocklink}prestashop>blocklink_7e5748d8c44f33c9cde08ac2805e5621'] = 'Bestellungssortierung erfolgreich aktualisiert';
$_MODULE['<{blocklink}prestashop>blocklink_46cff2568b00bc09d66844849d0b1309'] = 'Ein Fehler ist bei der Einstellung der Bestellungssortierung aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_58e9b25bb2e2699986a3abe2c92fc82e'] = 'Neuen Link hinzufügen';
$_MODULE['<{blocklink}prestashop>blocklink_ed2fc2838f7edb7607dd1cd19f3a82e0'] = 'Text:';
$_MODULE['<{blocklink}prestashop>blocklink_3b3d06023f6353f8fd05f859b298573e'] = 'URL:';
$_MODULE['<{blocklink}prestashop>blocklink_1f3674ab0d54a38327e8e4a0d97788d4'] = 'In neuem Fenster öffnen:';
$_MODULE['<{blocklink}prestashop>blocklink_7f3ee1818e42cfd668e361d89b8595fb'] = 'Diesen Link hinzufügen';
$_MODULE['<{blocklink}prestashop>blocklink_27a5ff9957ea16466ef085b53381e26a'] = 'Diesen Link bearbeiten';
$_MODULE['<{blocklink}prestashop>blocklink_b22c8f9ad7db023c548c3b8e846cb169'] = 'Blocktitel';
$_MODULE['<{blocklink}prestashop>blocklink_2c906769e7f8b03cc1fedce4e24a20c2'] = 'Blocktitel:';
$_MODULE['<{blocklink}prestashop>blocklink_67c94c1cba852f2d13eed115c938baf6'] = 'Block-URL:';
$_MODULE['<{blocklink}prestashop>blocklink_06933067aafd48425d67bcb01bba5cb6'] = 'Aktualisierung';
$_MODULE['<{blocklink}prestashop>blocklink_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocklink}prestashop>blocklink_53db43446b84dd2e9ddac626fc02ead3'] = 'Bestellliste:';
$_MODULE['<{blocklink}prestashop>blocklink_d36e9f57ea37903f81d28f7a189b9649'] = 'nach neuesten Links';
$_MODULE['<{blocklink}prestashop>blocklink_6ccdff04699ffe6956a6b1465907414a'] = 'nach ältesten Links';
$_MODULE['<{blocklink}prestashop>blocklink_387a8014f530f080bf2f3be723f8c164'] = 'Link-Liste';
$_MODULE['<{blocklink}prestashop>blocklink_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blocklink}prestashop>blocklink_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Text';
$_MODULE['<{blocklink}prestashop>blocklink_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklink}prestashop>blocklink_06df33001c1d7187fdd81ea1f5b277aa'] = 'Handlungen';
$_MODULE['<{blocklink}prestashop>blocklink_cad0a4e92b29bcb1ff1fc4f8524cfdc2'] = 'Es sind noch keine Links vorhanden';

?>