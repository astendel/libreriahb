<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Pagine non trovate';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_3ae7050d9f8502e9b69448a6db73fab2'] = 'Visualizza le pagine richieste dai visitatori ma non trovate';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_50004bd606668bb842e80f51337b765d'] = 'Pagine non trovate svuotate';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_23dbe39a97cb7e4e528f25f5795d317f'] = 'Pagine non trovate sono stati eliminati.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6cb944288ac528fcfd76b20156dddce1'] = 'È necessario utilizzare un file. Htaccess per reindirizzare gli errori 404 alla pagina \"404.php\"';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Pagina';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referente';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Contatore';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'Nessuna pagina registrata';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'database vuoto';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_190d2527535602ceed273f097040bef8'] = 'Svuotare tutte le pagine non si trova in questo periodo';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_254b5e94768b90388cc7002d362351f0'] = 'Elimina TUTTE le pagine non trovate';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guida';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'errori 404 ';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_1c4e115caef0bed8f5ca76da1909f967'] = 'Un errore 404 è un codice di errore HTTP che significa che il file richiesto dall\'utente non può essere trovato. Nel tuo caso significa che uno dei tuoi visitatori ha inserito un URL sbagliato nella barra degli indirizzi o che tu o un altro sito web ha un link morto da qualche parte. Quando è disponibile, il referente è mostrato in modo da poter trovare la pagina che contiene il link morti. Altrimenti in genere significa che si tratta di un accesso diretto, così forse qualcuno ha segnato un link che non esiste più.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Come individuare questi errori?';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_535ff57deda0b45d32cb37fd430accc8'] = 'Se il tuo provider supporta il file htaccess, è possibile crearlo nella directory principale di PrestaShop e inserirvi dentro la seguente riga:';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_9cfaa8e935f9e3e65b0959b15b070b15'] = 'Un utente che richiede una pagina che non esiste verrà reindirizzato alla pagina';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_feb436b0dabe28068aa6d866ac47bf0a'] = 'Questo modulo registra gli accessi a questa pagina: la pagina richiesta, la provenienza e il numero di volte che si è verificato.';

?>