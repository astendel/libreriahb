<?php

global $_MODULE;
$_MODULE = array();


$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'PÃ¡gina no encontrada';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_52a8f5d93ac4baca3b296bdef71248c6'] = 'Mostrar las pÃ¡ginas solicitadas por sus visitantes pero no encontradas';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6cb944288ac528fcfd76b20156dddce1'] = 'Usted debe utilizar un archivo .htaccess para volver a redirigir error 404 al \\\" de la pÃ¡gina; 404.php\\\"';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'PÃ¡gina';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referente';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Contador';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'PÃ¡gina no registrada';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'error 404';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_c7cf97a9d6cb9554b31a1158dd94c1c5'] = 'Error 404 es un cÃ³digo HTTP que significa que el archivo pedido por el usuario no se encuentre En su caso esto significa que uno de sus visitantes introdujo una URL incorrecto en la  barra de direcciÃ³n o que usted tiene un enlace roto en alguna parte. Cuando estÃ¡ disponible, se muestra el enlace  asÃ­ que usted puede encontrar la pÃ¡gina cuÃ¡l contiene el enlace roto. Si no, significa generalmente que es un acceso directo que ya no existe.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_535ff57deda0b45d32cb37fd430accc8'] = 'Si su servidor soporta el archivo .htaccess, usted puede crear en el directorio raÃ­z de PrestaShop e insertar la lÃ­nea siguiente:';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_260161f71496fa1b160c50c2c2ea2401'] = 'El usuario que busca una pÃ¡gina que no existe serÃ¡ devuelto a la pÃ¡gina';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_feb436b0dabe28068aa6d866ac47bf0a'] = 'Este mÃ³dulo registra los accesos a esta pÃ¡gina: la pÃ¡gina requerida, la refrencia y el nÃºmero de veces que se visito.';
