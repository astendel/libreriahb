<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Nicht gefundene Seiten';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_3ae7050d9f8502e9b69448a6db73fab2'] = 'Anzeige der Seiten, die Besucher aufrufen wollten, aber nicht gefunden haben';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_50004bd606668bb842e80f51337b765d'] = 'Nicht gefundene Seiten geleert';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_23dbe39a97cb7e4e528f25f5795d317f'] = 'Nicht gefundene Seiten wurden gelöscht';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6cb944288ac528fcfd76b20156dddce1'] = 'Sie müssen eine .htaccess-Datei benutzen, um 404-Fehler auf die Seit.php zu leiten';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Seite';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referrer';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Counter';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'Keine Seiten registriert';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Leere Datenbank';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_190d2527535602ceed273f097040bef8'] = 'Leere alle im Moment nicht gefunden Seiten';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_254b5e94768b90388cc7002d362351f0'] = 'Leere alle nicht gefunden Seiten';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Erklärung';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = '404-Fehler';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_1c4e115caef0bed8f5ca76da1909f967'] = 'Fehler 404 ist ein HTTP-Fehlercode, der besagt, dass die durch den Benutzer angeforderte Datei nicht gefunden werden kann. In Ihrem Fall bedeutet es, dass einer Ihrer Besucher eine falsche URL-Adresse in das Adressfeld eingegeben hat oder dass Sie oder eine andere Webseite irgendwo einen toten Link haben. Wenn sie verfügbar ist, wird der Referrer angezeigt, so dass Sie die Seite finden können, die den toten Link enthält. Ansonsten bedeutet es meist, dass es ein Direktzugang ist, dass also jemand einen Link, den es nicht mehr gibt, mit einem Bookmark versehen hat.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Wie fängt man diese Fehler ab?';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_535ff57deda0b45d32cb37fd430accc8'] = 'Falls Ihr Provider die .htaccess-Datei unterstützt, können Sie sie im Root-Verzeichnis von PrestaShop erstellen und folgende Zeile einfügen:';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_9cfaa8e935f9e3e65b0959b15b070b15'] = 'Ein Benutzer, der eine Seite aufruft, die es nicht gibt, wird zur Seite   weitergeleitet';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_feb436b0dabe28068aa6d866ac47bf0a'] = 'Dieses Modul protokolliert die Zugänge zu dieser Seite: die aufgerufene Seite, den Referrer und die Anzahl der Aufrufe.';

?>