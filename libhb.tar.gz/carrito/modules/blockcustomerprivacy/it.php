<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Privacy dei dati dei clienti';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_0cec62d1bea02fbb1484d55d14f493dd'] = 'Blocco dei dati dei clienti della privacy';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_3a32ec2dbd8d955f6240d95d6004557c'] = 'Aggiunge un blocco per visualizzare un messaggio circa la privacy dei dati dei clienti.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configurazione aggiornata';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b75fe4f32f17eb695f145704a8909146'] = 'Messaggio per la privacy dei dati dei clienti';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e6791c07164957bb87bfad5030f846'] = 'Messaggio che verrà visualizzato sotto forma di creazione dell\'account.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_2d4e74ab9c95452f5948cd959d186b6d'] = 'Suggerimento: Ricordate che se il testo è troppo lungo per essere scritto direttamente in forma, è possibile aggiungere un link ad una delle pagine create tramite la scheda CMS.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_ffeb523df77567c7fad7faf8af5f7e46'] = 'Si prega di concordare con la riservatezza dei dati dei clienti spuntando la casella qui sotto.';

?>