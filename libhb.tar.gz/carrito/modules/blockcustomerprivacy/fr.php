<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_0cec62d1bea02fbb1484d55d14f493dd'] = 'Bloc confidentialité des données clients';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_3a32ec2dbd8d955f6240d95d6004557c'] = 'Ajoute un bloc qui affiche un message concernant la confidentialité des données clients.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b75fe4f32f17eb695f145704a8909146'] = 'Message concernant la concernant la confidentialité des données clients.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e6791c07164957bb87bfad5030f846'] = 'Le message sera affiché sur le formulaire de création de compte.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_2d4e74ab9c95452f5948cd959d186b6d'] = 'Astuce : si votre texte est trop long pour être affiché entièrement sur le formulaire d\'inscription sans gêner la navigation, vous pouvez à la place indiquer un lien vers une des pages que vous avez créées via l\'onglet CMS.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_ffeb523df77567c7fad7faf8af5f7e46'] = 'Veuillez accepter nos conditions concernant la confidentialité des données clients, en cochant la case ci-dessous.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Confidentialité des données clients';
