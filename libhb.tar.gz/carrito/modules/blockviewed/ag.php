<?php

global $_MODULE;
$_MODULE = array();


$_MODULE['<{blockviewed}prestashop>blockviewed_859e85774d372c6084d62d02324a1cc3'] = 'Bloque de productos vistos';
$_MODULE['<{blockviewed}prestashop>blockviewed_3b2eba71c233156a12f94f26b3b188ab'] = 'AÃ±adir un bloque que muestre los Ãºltimos productos vistos';
$_MODULE['<{blockviewed}prestashop>blockviewed_7c19473789fd795286056bb0e2593382'] = 'Debes rellenar el campo \'Productos Mostrados\'';
$_MODULE['<{blockviewed}prestashop>blockviewed_73293a024e644165e9bf48f270af63a0'] = 'NÃºmero InvÃ¡lido.';
$_MODULE['<{blockviewed}prestashop>blockviewed_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmar';
$_MODULE['<{blockviewed}prestashop>blockviewed_c888438d14855d7d96a2724ee9c306bd'] = 'ConfiguraciÃ³n Actualizada';
$_MODULE['<{blockviewed}prestashop>blockviewed_f4f70727dc34561dfde1a3c529b6205c'] = 'ConfiguraciÃ³n';
$_MODULE['<{blockviewed}prestashop>blockviewed_e451e6943bb539d1bd804d2ede6474b5'] = 'Productos mostrados';
$_MODULE['<{blockviewed}prestashop>blockviewed_8ce2b5b3ffa27a8a66220a49357a1582'] = 'NÃºmero de productos mostrados en el bloque';
$_MODULE['<{blockviewed}prestashop>blockviewed_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockviewed}prestashop>blockviewed_43560641f91e63dc83682bc598892fa1'] = 'Lo mÃ¡s visto';
$_MODULE['<{blockviewed}prestashop>blockviewed_49fa2426b7903b3d4c89e2c1874d9346'] = 'MÃ¡s sobre';
