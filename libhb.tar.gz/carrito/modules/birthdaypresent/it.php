<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c2796655c25e1b0b8582716036aece08'] = 'Regalo di compleanno';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d1f5899bf2af57ed816390d9d740daf6'] = 'Offri automaticamente ai tuoi clienti dei regali di compleanno ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_ccfcf858237a83953c1ac03b5abde35e'] = 'Creare un voucher per i clienti che festeggiano il loro compleanno e che abbia almeno un ordine valido';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Attivo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_52292d2f9c39936bc72fbd47a3060df3'] = 'Inoltre, devi impostare una regola CRON che chiama il file';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f7e78e04cba74c610354e91e622cc105'] = 'tutti i giorni';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a1fa27779242b4902f7ae3bdd5c6d508'] = 'Tipo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_689202409e48743b914713f96d93947c'] = 'Valore';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_998d08a9606f9656e8d1fcab8b762155'] = 'L\'importo o la %, a seconda del tipo selezionato sopra';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_1f0084a1581c05622120bd827305f173'] = 'Ordine minimo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_783d0f2960c7c628177f740ce38ec3e7'] = 'Importo minimo di ordine necessario per utilizzare il voucher';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_38fb7d24e0d60a048f540ecb18e13376'] = 'Salva';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_19f823c6453c2b1ffd09cb715214813d'] = 'Campi obbligatori';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guida';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_cb21e843b037359d0fb5b793fccf964f'] = 'Sviluppa la fedeltà dei clienti ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d725bab433ae44aee759eb82a24b09de'] = 'Offrire un regalo a un cliente è un mezzo per ottenere la sua fedeltà.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_0dc42f38b35e45090e1a1c94755c2d43'] = 'Cosa devo fare?';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a3729d34db57cdeabe59a1fe78644458'] = 'Mantenere un cliente è più redditizio di conquistarne uno nuovo. Pertanto, è importante svilupparne la fedeltà, in altre parole, cercare di farlo tornare al tuo negozio online.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7b6ac3f2cdb42a4462ff7ca3c4358f71'] = 'Il passaparola è anche un mezzo per ottenere nuovi clienti soddisfatti; un cliente insoddisfatto non attira nuovi clienti.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_410008089d5bb723438103a84d48a59c'] = 'Per raggiungere questo obiettivo è possibile organizzare:';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_3e788301a1b0ce341aa5ce15bc520545'] = 'Operazioni regolari: premi commerciali (offerte speciali personalizzate, prodotto o servizio offerto), premi non commerciale (gestione prioritaria di un ordine o di un prodotto), premi pecuniari (obbligazioni, buoni sconto, reinvestimenti ...).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f299b58558601a85c98a2d1d7867d523'] = 'Operazioni sostenibili: carte fedeltà o punti, che non solo giustificano la comunicazione tra commerciante e cliente, ma offre anche vantaggi ai clienti (offerte private, sconti).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d434c183a411611f50fa7e121b0f6565'] = 'Queste operazioni incoraggiano i clienti a comprare e a tornare al tuo negozio online regolarmente.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d46bd07675d08116e85f8a4c7866de53'] = 'Il tuo regalo di compleanno!';

?>