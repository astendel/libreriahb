<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c2796655c25e1b0b8582716036aece08'] = 'Geburtstagsgeschenk';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d1f5899bf2af57ed816390d9d740daf6'] = 'Bieten Sie Ihren Kunden automatisch Geburtstagsgeschenke an';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_ccfcf858237a83953c1ac03b5abde35e'] = 'Erstellen Sie einen Gutschein für Kunden, die Geburtstag haben und mind. eine Bestellung bereits getätigt haben.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Aktiv';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_52292d2f9c39936bc72fbd47a3060df3'] = 'Sie müssen zusätzlich eine cron-Regel einstellen, die die Datei aufruft';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f7e78e04cba74c610354e91e622cc105'] = 'jeden Tag';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a1fa27779242b4902f7ae3bdd5c6d508'] = 'Typ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_689202409e48743b914713f96d93947c'] = 'Wert';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_998d08a9606f9656e8d1fcab8b762155'] = 'Entweder den Geldbetrag oder den Prozentsatz, je nach oben ausgewähltem Typ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_1f0084a1581c05622120bd827305f173'] = 'Mindestbestellung';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_783d0f2960c7c628177f740ce38ec3e7'] = 'Mindestbestellwert, um den Gutschein nutzen zu können';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_38fb7d24e0d60a048f540ecb18e13376'] = 'Speichern';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_19f823c6453c2b1ffd09cb715214813d'] = 'Pflichtfeld';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_6602bbeb2956c035fb4cb5e844a4861b'] = 'Erklärung';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_cb21e843b037359d0fb5b793fccf964f'] = 'Kundenbindung ausbauen';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d725bab433ae44aee759eb82a24b09de'] = 'Kundengeschenke sind ein Mittel zur Kundenbindung.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_0dc42f38b35e45090e1a1c94755c2d43'] = 'Was müssen Sie tun?';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a3729d34db57cdeabe59a1fe78644458'] = 'Wiederkehrender Kunden zu pflegen ist profitabler, als immer neue zu gewinnen. Daher ist es empfehlenswert, deren Vertrauen aufzubauen und ihnen das Wiederkommen so angenehm wie möglich zu gestalten.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7b6ac3f2cdb42a4462ff7ca3c4358f71'] = 'Ein guter Ruf ist ebenso ein Mittel, zufriedene Kunden zu bekommen; ein unzufriedener Kunde zieht keine Neukunden an.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_410008089d5bb723438103a84d48a59c'] = 'Um dieses Ziel zu erreichen, können Sie Folgendes organisieren:';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_3e788301a1b0ce341aa5ce15bc520545'] = 'Punktuelle Aktionen: kommerzielle Vergünstigungen (persönliche Sonderangebote, Gratis-Produkte oder -Services), nicht-kommerzielle Vergütungen (bevorzugte Behandlung einer Bestellung oder eines Produkts), geldliche Vergünstigungen (Gutscheine, Ermäßigungsgutscheine, PayBack...)';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f299b58558601a85c98a2d1d7867d523'] = 'Nachhaltige Aktionen: Treue- oder Kundenkarte, die nicht nur der Kommunikation zwischen Händler und Kunden dient, sondern Kunden auch Vorteile bietet (Persönliche Angebote, Ermäßigungen).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d434c183a411611f50fa7e121b0f6565'] = 'Diese Operation bewegt die Kunden dazu, in IHrem Shop regelmäßig einzukaufen.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d46bd07675d08116e85f8a4c7866de53'] = 'Ihr Geburtstagsgeschenk!';

?>