<?php

global $_MODULE;
$_MODULE = array();


$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c2796655c25e1b0b8582716036aece08'] = 'Regalo de aniversario';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d1f5899bf2af57ed816390d9d740daf6'] = 'Ofresca a sus clientes regalos de aniversario automaticamente';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_487011dccb5c5f3f8b6cfa32b1d4c4b9'] = 'Crear un bono para sus clientes por la celebraciÃ³n de sus cumpleaÃ±os';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_59cb7946b9d916e80a7e05defd004120'] = 'Adicionalemente , usted tiene que establecer una regla CRON  que pida el archivo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_9939846b096f52609cb7c31de24e20e7'] = 'todos los dias';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a1fa27779242b4902f7ae3bdd5c6d508'] = 'Tipo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_689202409e48743b914713f96d93947c'] = 'Valor';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_998d08a9606f9656e8d1fcab8b762155'] = 'sea cantidad monetaria o el %, dependiendo del tipo seleccionado anteriormente';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c7778a6285eb4d3ab3e63577d01d8c9e'] = 'Pedido minimo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7965459711eef00cc851228b488a46f4'] = 'La cantidad mÃ­nima del pedido necesaria para utilizar el vale ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_38fb7d24e0d60a048f540ecb18e13376'] = 'Guardar';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_19f823c6453c2b1ffd09cb715214813d'] = 'Archivo requerido';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guia';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_cb21e843b037359d0fb5b793fccf964f'] = 'Desarrolle la fidelizaciÃ³n de sus clientes';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d7310108a7af8ab125b7b69d602f9a8a'] = 'Ofrecer un regalos a sus clientes, quiere decir fidelizarlos';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_e1b9cd2cf691574ade4e2e1077b03441'] = 'Conservar un cliente es mÃ¡s provechoso que captar  uno nuevo. AsÃ­, es necesario desarrollar su lealtad, es decir hacer todo para que vuelva a su webshop.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7b6ac3f2cdb42a4462ff7ca3c4358f71'] = 'El boca a boca es uno de los mejores medios de conseguir a nuevos clientes satisfechos; un cliente contento te atraerÃ¡  nuevos clientes.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_410008089d5bb723438103a84d48a59c'] = 'Para alcanzar esta meta usted puede organizar: ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_3e788301a1b0ce341aa5ce15bc520545'] = 'Operaciones puntuales: recompensas comerciales (ofertas especiales personalizadas, producto o servicio ofrecidos), recompensas no comerciales (prioridad en el envÃ­o  de un pedido  o de un producto), recompensas pecuniarias (enlaces, cupones del descuento, prioridad en el reembolsoâ€¦).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f299b58558601a85c98a2d1d7867d523'] = 'Operaciones sostenibles: las tarjetas de fidelidad o de puntos, que no sÃ³lo justifican la comunicaciÃ³n entre el comerciante y el cliente, pero tambiÃ©n ofrecen ventajas a los clientes (ofertas, descuentos privados).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_49c8045b620233da0fa2d7088b2cb1c9'] = 'Estas operaciones animan a clientes a comprar y tambiÃ©n a volver a tienda virtual regularmente.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d46bd07675d08116e85f8a4c7866de53'] = 'Su regalo de cumpleaÃ±os!';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_ae1e2f44f5d28cf8e14e1a30cc105060'] = 'Feliz cumpleaÃ±os!';
