<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c2796655c25e1b0b8582716036aece08'] = 'Cadeau d\'anniversaire';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d1f5899bf2af57ed816390d9d740daf6'] = 'Offrez automatiquement à vos clients des cadeaux d\'anniversaire';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_ccfcf858237a83953c1ac03b5abde35e'] = 'Créer un bon de réduction pour les clients fêtant leur anniversaire et ayant au moins une commande valide';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Actif';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_52292d2f9c39936bc72fbd47a3060df3'] = 'De plus, vous devez installer une règle CRON qui appellera le fichier';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f7e78e04cba74c610354e91e622cc105'] = 'chaque jour';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a1fa27779242b4902f7ae3bdd5c6d508'] = 'Type';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_689202409e48743b914713f96d93947c'] = 'Valeur';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_998d08a9606f9656e8d1fcab8b762155'] = 'Soit le montant soit le pourcentage selon votre choix précédent';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_1f0084a1581c05622120bd827305f173'] = 'Commande minimum';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_783d0f2960c7c628177f740ce38ec3e7'] = 'Montant minimum de la commande pour que le bon soit utilisable';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_38fb7d24e0d60a048f540ecb18e13376'] = 'Sauvegarder';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_19f823c6453c2b1ffd09cb715214813d'] = 'Champ requis';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_cb21e843b037359d0fb5b793fccf964f'] = 'Fidéliser le client';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d725bab433ae44aee759eb82a24b09de'] = 'Offrir un cadeau d\'anniversaire à un client est une manière comme une autre d\'agir sur sa fidélité.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_0dc42f38b35e45090e1a1c94755c2d43'] = 'Que faire ?';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a3729d34db57cdeabe59a1fe78644458'] = 'Garder un client est plus rentable que d’en conquérir un nouveau. Il est donc impératif de le fidéliser, c\'est-à-dire de le faire revenir sur votre boutique. ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7b6ac3f2cdb42a4462ff7ca3c4358f71'] = 'Le bouche à oreille est également un moyen d\'avoir de nouveaux clients satisfaits ; car un client non satisfait n\'en attirera pas de nouveaux. ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_410008089d5bb723438103a84d48a59c'] = 'Pour y parvenir, plusieurs moyens existent :';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_3e788301a1b0ce341aa5ce15bc520545'] = 'Les opérations ponctuelles : les récompenses marchandes (offres promotionnelles ciblées et personnalisées, cadeaux -produit ou service offert-), les récompenses non marchandes (traitement prioritaire d\'une commande ou d\'un produit), les récompenses pécuniaires (bons d\'achat, de réduction, de remboursement). ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f299b58558601a85c98a2d1d7867d523'] = 'Les opérations pérennes : (carte de fidélité, points de fidélité) qui non seulement justifient la communication marchand-clients, et aussi offre des avantages aux clients (offres privatives, réductions).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d434c183a411611f50fa7e121b0f6565'] = 'Ces opérations encouragent les clients à acheter et aussi à revenir sur votre boutique en ligne régulièrement.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d46bd07675d08116e85f8a4c7866de53'] = 'Votre cadeau d\'anniversaire !';
