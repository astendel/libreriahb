<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c2796655c25e1b0b8582716036aece08'] = 'Regalo de cumpleaños';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d1f5899bf2af57ed816390d9d740daf6'] = 'Haga a sus clientes regalos de cumpleaños automáticamente';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_ccfcf858237a83953c1ac03b5abde35e'] = 'Crear un bono para los clientes que celebran su cumpleaños y que tiene por lo menos un pedido válido';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_52292d2f9c39936bc72fbd47a3060df3'] = 'Adicionalemente, debe establecer una regla CRON que pida el archivo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f7e78e04cba74c610354e91e622cc105'] = 'todos los días';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a1fa27779242b4902f7ae3bdd5c6d508'] = 'Tipo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_689202409e48743b914713f96d93947c'] = 'Valor';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_998d08a9606f9656e8d1fcab8b762155'] = 'cantidad monetaria o porcentaje dependiendo del tipo seleccionado anteriormente';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_1f0084a1581c05622120bd827305f173'] = 'Pedido mínimo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_783d0f2960c7c628177f740ce38ec3e7'] = 'Cantidad de pedido mínimo para utilizar el vale';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_38fb7d24e0d60a048f540ecb18e13376'] = 'Guardar';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_19f823c6453c2b1ffd09cb715214813d'] = 'Archivo necesario';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_cb21e843b037359d0fb5b793fccf964f'] = 'Desarrolle la fidelización de sus clientes';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d725bab433ae44aee759eb82a24b09de'] = 'Haciendo regalos a sus clientes está seguro de fidelizarlos.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_0dc42f38b35e45090e1a1c94755c2d43'] = '¿Cómo hacer?';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a3729d34db57cdeabe59a1fe78644458'] = 'Conservar un cliente es más ventajoso que captar uno nuevo. Así, es necesario desarrollar su lealtad, es decir hacer todo lo posible para que vuelva a su local.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7b6ac3f2cdb42a4462ff7ca3c4358f71'] = 'El boca a boca es uno de los mejores métodos para conseguir nuevos clientes satisfechos; un cliente contento atraerá otros nuevos clientes.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_410008089d5bb723438103a84d48a59c'] = 'Para alcanzar este objetivo usted puede organizar:';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_3e788301a1b0ce341aa5ce15bc520545'] = 'Operaciones puntuales: recompensas comerciales (ofertas especiales personalizadas, producto o servicios ofrecidos), recompensas no comerciales (prioridad en el envío  de un pedido  o de un producto), recompensas pecuniarias (enlaces, cupones del descuento, prioridad en el reembolso...).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f299b58558601a85c98a2d1d7867d523'] = 'Operaciones sostenibles: las tarjetas de fidelidad o de puntos, que no sólo justifican la comunicación entre el comerciante y el cliente, pero también ofrecen ventajas a los clientes (ofertas, descuentos privados).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d434c183a411611f50fa7e121b0f6565'] = 'Estas operaciones animan a los clientes a comprar y también a volver a su local en línea frecuentemente.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d46bd07675d08116e85f8a4c7866de53'] = '¡Su regalo de cumpleaños!';
